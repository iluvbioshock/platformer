package com.scottk.platformer.controller;

/**
 * Created by Student on 1/26/2015.
 */
public class InputControl {
}
