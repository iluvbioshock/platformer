package com.example.mymodule.app;

public class MyClass {
}
